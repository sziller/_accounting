# FileProcessing

Package to help reading and writing of different file types.
Also converting read data into predefined structures.

Building packages: - when in root(!) folder (FileProcessing) in command line type:
python setup.py sdist bdist_wheel

setup.py needs to be filled in, and - i believe - __init.py__ needs at least to exist. -dunno

To install: pip install ...