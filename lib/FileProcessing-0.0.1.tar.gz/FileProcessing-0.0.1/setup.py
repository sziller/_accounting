#!/usr/bin/python3.7

from setuptools import setup

'''
complete install
'''
'''-----------------------------------------------------------------------------------
- sziller.eu install - DO NOT FORGET THE MANIFEST.in file + check requirements !!!!! -
-----------------------------------------------------------------------------------'''
# because of different content, Full packages always have an even version nr. at the end!!!
# make sure, the full version's number is always higher than any version including less info.
# python setup.py sdist bdist_wheel

setup(
    name='FileProcessing',  # package name, used at pip or tar.
    version='0.0.1',  # version Nr - please update when
    packages=['FileProcessing'],  # string-list of packages to be translated
    url='',  # if url is used at all
    license='',  # ...
    author='Sziller',  # well obvious
    author_email='sziller@gmail.com',
    description='Package to help reading and writing of different file types.'
                ' Also converting read data into predefined structures.',  # please always check, extend if necessary
    install_requires=["pytest",
                      "pyaml",
                      "openpyxl"],  # string-list of necessary packages, please update
    dependency_links=[],  # if dependent on external projects
)
