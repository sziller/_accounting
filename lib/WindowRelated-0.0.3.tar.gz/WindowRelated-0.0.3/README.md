# WindowRelated

Package including window related functions and classes.
Based on tkinter